window.assetAfterStylesheetLoaded = true
